import MealPlanner from "./MealPlanner";

function App() {
  return (
    <div style={{ padding: "1rem" }}>
      <h1 style={{ textAlign: "center" }}>מתכנן אוכל ל-3 ימים</h1>
      <MealPlanner />
    </div>
  );
}

export default App;