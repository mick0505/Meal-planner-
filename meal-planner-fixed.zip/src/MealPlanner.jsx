import { useState } from "react";

const days = ["יום 1", "יום 2", "יום 3"];
const meals = ["בוקר", "צהריים", "ערב", "חטיפים"];

export default function MealPlanner() {
  const [plan, setPlan] = useState({});
  const [newDish, setNewDish] = useState("");
  const [newIngredient, setNewIngredient] = useState("");
  const [shoppingList, setShoppingList] = useState([]);

  const handleAddDish = (day, meal) => {
    if (!newDish) return;
    const key = `${day}-${meal}`;
    setPlan((prev) => ({
      ...prev,
      [key]: [...(prev[key] || []), { name: newDish, ingredients: [] }],
    }));
    setNewDish("");
  };

  const handleAddIngredient = (day, meal, index) => {
    if (!newIngredient) return;
    const key = `${day}-${meal}`;
    const updatedDishes = [...(plan[key] || [])];
    updatedDishes[index].ingredients.push(newIngredient);
    setPlan((prev) => ({
      ...prev,
      [key]: updatedDishes,
    }));
    setNewIngredient("");
  };

  const generateShoppingList = () => {
    const allIngredients = {};
    Object.values(plan).forEach((dishes) => {
      dishes.forEach((dish) => {
        dish.ingredients.forEach((ingredient) => {
          allIngredients[ingredient] = (allIngredients[ingredient] || 0) + 1;
        });
      });
    });
    setShoppingList(Object.entries(allIngredients));
  };

  return (
    <div>
      {days.map((day) => (
        <div key={day} style={{ background: "#fff", padding: "1rem", marginBottom: "1rem", borderRadius: "8px" }}>
          <h2>{day}</h2>
          {meals.map((meal) => {
            const key = `${day}-${meal}`;
            return (
              <div key={key} style={{ marginBottom: "1rem" }}>
                <h3>{meal}</h3>
                <ul>
                  {(plan[key] || []).map((dish, index) => (
                    <li key={index}>
                      {dish.name}
                      <ul style={{ marginRight: "1rem", fontSize: "0.9em", color: "#555" }}>
                        {dish.ingredients.map((ing, i) => (
                          <li key={i}>{ing}</li>
                        ))}
                      </ul>
                      <div style={{ marginTop: "0.5rem" }}>
                        <input
                          placeholder="הוסף מרכיב..."
                          value={newIngredient}
                          onChange={(e) => setNewIngredient(e.target.value)}
                        />
                        <button onClick={() => handleAddIngredient(day, meal, index)}>הוסף מרכיב</button>
                      </div>
                    </li>
                  ))}
                </ul>
                <div>
                  <input
                    placeholder="הוסף מנה..."
                    value={newDish}
                    onChange={(e) => setNewDish(e.target.value)}
                  />
                  <button onClick={() => handleAddDish(day, meal)}>הוסף</button>
                </div>
              </div>
            );
          })}
        </div>
      ))}
      <div>
        <button onClick={generateShoppingList}>צור רשימת קניות</button>
        {shoppingList.length > 0 && (
          <div style={{ marginTop: "1rem", background: "#fff", padding: "1rem", borderRadius: "8px" }}>
            <h3>רשימת קניות</h3>
            <ul>
              {shoppingList.map(([ingredient, count]) => (
                <li key={ingredient}>{ingredient} × {count}</li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}