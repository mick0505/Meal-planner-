import MealPlanner from "./MealPlanner";

function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-2xl font-bold mb-6 text-center">מתכנן אוכל ל-3 ימים</h1>
      <MealPlanner />
    </div>
  );
}

export default App;