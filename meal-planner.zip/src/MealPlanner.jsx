import { useState } from "react";

const days = ["יום 1", "יום 2", "יום 3"];
const meals = ["בוקר", "צהריים", "ערב", "חטיפים"];

export default function MealPlanner() {
  const [plan, setPlan] = useState({});
  const [newDish, setNewDish] = useState("");
  const [newIngredient, setNewIngredient] = useState("");

  const handleAddDish = (day, meal) => {
    if (!newDish) return;
    const key = `${day}-${meal}`;
    setPlan((prev) => ({
      ...prev,
      [key]: [...(prev[key] || []), { name: newDish, ingredients: [] }],
    }));
    setNewDish("");
  };

  const handleAddIngredient = (day, meal, index) => {
    if (!newIngredient) return;
    const key = `${day}-${meal}`;
    const updatedDishes = [...(plan[key] || [])];
    updatedDishes[index].ingredients.push(newIngredient);
    setPlan((prev) => ({
      ...prev,
      [key]: updatedDishes,
    }));
    setNewIngredient("");
  };

  return (
    <div className="p-4 grid gap-4">
      {days.map((day) => (
        <div key={day} className="bg-white p-4 rounded shadow">
          <h2 className="text-xl font-bold mb-2">{day}</h2>
          {meals.map((meal) => {
            const key = `${day}-${meal}`;
            return (
              <div key={key} className="mb-4">
                <h3 className="font-semibold">{meal}</h3>
                <ul className="list-disc list-inside">
                  {(plan[key] || []).map((dish, index) => (
                    <li key={index}>
                      {dish.name}
                      <ul className="list-circle list-inside ml-4 text-sm text-gray-600">
                        {dish.ingredients.map((ing, i) => (
                          <li key={i}>{ing}</li>
                        ))}
                      </ul>
                      <div className="flex gap-2 mt-1">
                        <input
                          placeholder="הוסף מרכיב..."
                          value={newIngredient}
                          onChange={(e) => setNewIngredient(e.target.value)}
                          className="border p-1 rounded text-sm"
                        />
                        <button
                          onClick={() => handleAddIngredient(day, meal, index)}
                          className="bg-blue-500 text-white text-sm px-2 py-1 rounded"
                        >
                          הוסף מרכיב
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>
                <div className="flex gap-2 mt-2">
                  <input
                    placeholder="הוסף מנה..."
                    value={newDish}
                    onChange={(e) => setNewDish(e.target.value)}
                    className="border p-1 rounded text-sm"
                  />
                  <button
                    onClick={() => handleAddDish(day, meal)}
                    className="bg-green-500 text-white text-sm px-2 py-1 rounded"
                  >
                    הוסף
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}